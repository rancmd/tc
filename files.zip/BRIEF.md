# Task Crusher — Project Brief

A motivational, minimal task manager styled after Google Search.
The philosophy: **one task at a time, make crushing it feel good**.

---

## Core Concept

- You see **one task** front and center — big, bold, full focus
- Clicking the task **crushes it** (done animation + confetti)
- A **+** FAB (bottom right) adds new tasks
- Tasks can be **pushed** (deferred without shame) or **split** into subtasks
- Minimal, dark UI — electric yellow-green (#BFFF00) accent

---

## File Structure

```
task-crusher/
  index.html   — markup & modal shells
  style.css    — all styling (tokens, layout, components)
  app.js       — all logic (state, render, storage, events)
```

---

## Features (current prototype)

| Feature | Status |
|---|---|
| Add task via FAB (+) modal | ✅ |
| Tag tasks (time + vibe) | ✅ |
| Crush task → confetti + flash | ✅ |
| Push task (skip / end of list / tomorrow) | ✅ |
| Split task into subtasks (each is independent) | ✅ |
| Quick actions row (Skip · Split · More) | ✅ |
| Full action modal (time, priority, push, split, delete) | ✅ |
| All tasks list overlay (Active / Done / All filters) | ✅ |
| Task count in header (with ✅ done count in green) | ✅ |
| localStorage persistence | ✅ |
| PWA manifest (installable) | ✅ |
| Keyboard shortcuts (Esc, Enter) | ✅ |

---

## Design Tokens

| Token | Value |
|---|---|
| Background | `#0a0a0a` |
| Surface | `#141414` |
| Surface 2 | `#1c1c1c` |
| Border | `#2a2a2a` |
| Accent (yellow-green) | `#BFFF00` |
| Green (done/crush) | `#4ade80` |
| Danger | `#ff4545` |
| Font | Space Grotesk |

---

## Interaction Model

1. **Empty state** — random motivational prompt shown
2. **Task displayed** — click the card to crush it; hover shows "✊ Crush it!" in green
3. **Subtasks** — shown as individual cards below parent, each crushable independently
4. **Push** — Skip (next), End of list, or Tomorrow (no animation, no guilt)
5. **List overlay** — tap the task count in top-right to open; filter Active / Done / All

---

## Planned / Future

- [ ] Full-screen timer (Pomodoro style)
- [ ] Supabase sync (cross-device)
- [ ] Big illustrated crush animation (replace confetti)
- [ ] AI-assisted task splitting (Anthropic API)
- [ ] Recurring tasks
- [ ] Sorting/filtering by tag (urgent, easy, fun, time)

---

## My Task Backlog

> Add tasks below to import / reference in next session:

- [ ] 
- [ ] 
- [ ] 

---

## Notes for Next Session

> Paste any issues, ideas, or context here before starting:

